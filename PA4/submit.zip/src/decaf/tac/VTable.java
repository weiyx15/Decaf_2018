package decaf.tac;

public class VTable {
	public String name;
	
	public VTable parent;
	
	public String className;

	public Label[] entries;
}
